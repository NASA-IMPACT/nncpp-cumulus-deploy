const resolve = require('./resolve');

module.exports = {
  resolve,
};

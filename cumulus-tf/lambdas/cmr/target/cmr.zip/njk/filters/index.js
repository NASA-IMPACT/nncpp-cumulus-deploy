const selectAttr = require("./selectAttr");

/*
 * A name/function mapping to use as "filters" in a Nunjucks environment.
 */
module.exports = {
  selectattr: selectAttr
};

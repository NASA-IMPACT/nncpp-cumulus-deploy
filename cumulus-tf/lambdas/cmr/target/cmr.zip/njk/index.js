const NJK = require("./NJK");

module.exports = NJK;
